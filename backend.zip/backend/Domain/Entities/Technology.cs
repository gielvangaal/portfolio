using Domain.Enums;

namespace Domain.Entities;

public class Technology
{
    public int Id { get; set; }

    public required string Name { get; set; }

    public TechnologyUsage Usage { get; set; }

    public int? MediaId { get; set; }
    public Media? Media { get; set; }

    public ICollection<PortfolioItem> PortfolioItems { get; set; } = [];
    public ICollection<Category> Categories { get; set; } = [];
}